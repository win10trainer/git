﻿
# Importieren Sie die Benutzer aus der CSV-Datei NeueUser.csv mit Hilfe des Scripts NeueUser.ps1
# Bearbeiten Sie dazu die Datei NeueUser.ps1 und tragen Sie den korrekten Pfad ein.
# Überprüfen Sie, ob die Benutzer auch erstellt wurden. Zeigen Sie einfach alle Benutzer der Domäne an.


 
# Ermitteln Sie die Eigenschaften und Methoden des Befehls get-aduser mit dem CmdLet get-member


 
# Ermitteln Sie alle aktuell vorhandenen User und geben Sie nur die Namen aus



# Ermitteln Sie alle deaktivierten Benutzerkonten und geben Sie Namen und Status aus





# Geben Sie nur Benutzer aus, die mit "adm" beginnen, wobei auch der Wert von Department angezeigt werden soll.



# Aktivieren Sie das Konto Gast, prüfen Sie den Status und deaktivieren Sie es wieder






# Erstellen Sie den Benutzer Hans Wurst mit dem Anmeldenamen HansW dem Wert "Marketing Sued" für die Abteilung in der entsprechenden OU. Hans Wurst
# hat den Titel Marketingleiter und sitzt in München. Er soll das Kennwort Pa$$w0rd verwenden, das Konto soll aktiviert sein.
# Das Kennwort muss ein secure string sein. Verwenden Sie Klartext (siehe oben)



# Melden Sie sich mit dem neuen Konto am Client an und dann wieder als ps\administrator

# Ändern Sie das Kennwort von Hans Wurst auf Passw0rd1




# Ergänzen Sie die Daten von Hans Wurst mit der 
# Büro-Telefonnummer 030 311311 (officePhone)
# und der Mobilnummer 015258408442 (MobilePhone)



# Prüfen Sie diese Werte bei Hans



# Verschieben Sie Hans Wurst aus der aktuellen OU in die OU Management



# Setzen Sie das Ablaufdatum des Kontos Karin.Ahnungslos auf den morgigen Tag



# Suchen Sie nach Benutzern, deren Konto innerhalb von 14 Tagen abläuft



# Suchen Sie nach Benutzern, die seit 30 Tagen inaktiv waren



# Suchen Sie nach Konten, die sich noch nie angemeldet haben. Logoncount ist dann 0 (Null). Geben Sie den Namen aus



