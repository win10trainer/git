﻿
# Ermitteln Sie die Eigenschaften und Methoden von Gruppen des Active Directory



# listen Sie die vorhanden Gruppennamen und deren Gruppenbereich auf



# Listen Sie nur Globale AD Sicherheitsgruppen mit Namen,Bereich und Category auf



# Erstellen  Sie eine neue globale Sicherheitgruppe Marketing in der OU Marketing



# Erstellen Sie auf gleiche Weise die Gruppen für Marketing Sued und Nord



# Fügen Sie die Marketing Sued und die Marketing Nord Gruppe als Mitglieder in die Gruppe Marketing auf



# Prüfen Sie die Mitgliedschaft in der Marketinggruppe und zeigen Sie nur die Mitgliedernamen an


# Otto Hering gehört in die Gruppe Marketing Nord, fügen Sie ihn als Mitglied hinzu.



# Prüfen Sie die Mitgliedschaft von Otto Hering in der Gruppe



# prüfen Sie die Gruppenmitgliedschaften von Marketing rekursiv und geben Sie nur die Mitgliedernamen aus



# Erstellen Sie die globale Sicherheitsgruppe Manager und nehmen Sie alle Benutzer auf, die CEO oder Leiter oder Leiterin sind (Eigenschaft: title)





# prüfen Sie die Mitgliedschaft in dieser Gruppe



# Erstellen Sie eine globale Gruppe aller Benutzer mit dem Title Angestellter mit dem Namen Angestellte


 
# Nehmen Sie alle benutzer mit dem Title Angesteller oder Angestellte in die Gruppe auf








