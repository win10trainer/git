﻿# erstellen Sie eine Funktion convert-InchToCm, die Inches in cm umwandelt. Der Inch-Wert soll als verpflichtender Parameter übergeben werden.



function  convert-InchToCm {

[cmdletbinding()]

           Param
              (
                                 
                
                          
                )
                          
               Begin
                    {
                    }
               Process
                      {
                          
                       

                      }
                End
                    {
                    }
          } #end function



# Erstellen sie die Function Run-HelpShowWindow, die mit einem cmdlet-Namen aufgerufen werden muss und
# dafür sorgt, dass für das CmdLet die Hilfe von Get-Help mit dem Parameter -Showwindows ausgeführt wird
#  Wenn Sie es können, versuchen Sie einen [ValidatePattern("")] im Parameterblock einzusetzen, das über-
# prüft, ob es sich um ein CmdLet handeln könnte (Muster: verb-noun)

function Run-HelpShowWindow {

[CmdLetBinding()]

Param (


        )

Process
    {

    

    }

}






