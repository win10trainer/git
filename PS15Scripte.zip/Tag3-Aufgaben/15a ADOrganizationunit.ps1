﻿# Listen Sie die CmdLets des Modules ActiveDirectory auf


# Mit welchem Befehl kann man Organisationseinheiten erstellen? 
# Erstellen Sie die OU Marketing im Stamm der Domäne mit der Beschreibung "Marketing OU"
# Ermöglichen Sie das Löschen der Organisationseinheit (-ProtectedFromAccidentalDeletion $false)



# Zeigen Sie nur die Marketing OU an



# Erstellen Sie in der Marketing OU die Unterorganisationseinheiten "Marketing Sued" und "Marketing Nord" sowie "Online Marketing" ohne Schutz vor versehentlichem Löschen




# Erstellen Sie die Organisationseinheiten Management und IT im Stamm der Domäne 




# Zeigen Sie die OUs an, die in der OU Marketing liegen und geben Sie nur die Namen an. Verwenden Sie searchbase und searchscope



# Zeigen Sie die Namen aller OUs der gesamten Domäne an und ihren Ldap-Pfad






