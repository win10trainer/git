﻿# Command, das jetzt in ein parametrisiertes Script und dann später in ein Modul umgewandelt werden soll



Get-WmiObject -Class Win32_LogicalDisk -Filter "DriveType=3" -ComputerName localhost |`
where Deviceid -eq "C:" | 
select -Property    @{n='DriveLetter';e={$_.DeviceID}},`                    @{n='FreeSpace(GB)';e={"{0:N2}"-f ($_.FreeSpace /1GB)}}, `                    @{n='Size';e={"{0:N2} GB" -f ($_.Size / 1GB)}}, `                    @{n='Free %';e={"{0:N2} %" -f ($_.Freespace / $_.Size *100)}}                    Write-host "Fertig"