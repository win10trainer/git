﻿ # Die richtige Datei wählen, Pfadangabe!
 $users = import-csv "--->Ihr Pfad zur Datei\NeueUser.csv<----"

 #Kopfzeile der CSV-Datei: Name,samaccountname,Title,Path,City,department,givenname,surname

 Foreach ($User in $users) {

 $Password = ConvertTo-SecureString 'Passw0rd' -AsPlainText -Force

 New-aduser -Name $user.name -SamAccountName $user.samaccountname -Title $user.title -AccountPassword $Password -path $user.path  -city $user.city -givenname $user.givenname -surname $user.surname -Department $User.department -Enabled $true
 } # ende foreach