﻿get-help stop-process -ShowWindow

<#  Die Bindung kann bei ByValue und bei PropertyName stattfinden
-InputObject <Process[]>
        Specifies the process objects to stop. Enter a variable that contains the objects, or type a command or expression that gets the objects.

        Erforderlich?                  true
        Position?                      0
        Standardwert                   None
        Pipelineeingaben zulassen?     True (ByValue) <---- Typ Prozess kann gebunden werden
        Platzhalterzeichen zulassen?   false
-Name <String[]>
        Specifies the process names of the processes to stop. You can type multiple process names, separated by commas, or use wildcard characters.

        Erforderlich?                  true
        Position?                      named
        Standardwert                   None
        Pipelineeingaben zulassen?     True (ByPropertyName) <---- Eine Eigenschaft mit dem Namen "Name" kann gebunden werden
        Platzhalterzeichen zulassen?   false


#>

Start-Process notepad # wir starten notepad

Get-Process -Name notepad # Der Prozess wird erfasst

Get-Process -Name notepad | get-member # Es handelt sich um ein Prozess-Objekt TypeName: System.Diagnostics.Process

Get-Process -Name notepad | Stop-Process # Es gibt eine Bindung ByValue

# Im folgenden wird ein Objekt übergeben, das KEIN Prozess-Objekt darstellt

Start-Process notepad

 
$o = new-object -TypeName PSCustomObject
$o | Add-Member -MemberType noteProperty -Name Name -Value notepad

$o | Get-Member # Das PSCustomObject hat eine Property "Name", ist aber definitiv kein Process-Objekt

$o | Stop-Process   # Notepad wird beendet, weil die Eigenschaft Name gebunden werden konnte

# Die Übergabe eines Strings reicht nicht aus   
Start-Process notepad
"notepad" | Stop-Process       