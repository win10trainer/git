﻿# Instanzen sind Objekte, deren Eigenschaften und Methoden durch Klassen definiert werden

# Z.B. ist die WMI-Klasse Win32_BIOS nur mit einer Instanz verbunden, d.h. es gibt nur ein BIOS-Objekt

# Dagegen kann es mehrere Netzwerkkarten in einem System geben. Für jede Netzwerkkarte gibt es
# daher ein Objekt, dessen Eigenschaften und Methoden bearbeitet werden können. Jede Netzwerkkarte
# stellt eine Instanz der Netzwerkkartenklasse dar.

Get-NetAdapter # Ermittelt alle Netzwerkadapterinstancen

# Der Get-Member Befehl kann die Methoden und Eigenschaften von Objekten anzeigen:

Get-NetAdapter | Get-Member # Ermittelt die Eigenschaften und Methoden für Netzwerkadapter

# TypeName: Microsoft.Management.Infrastructure.CimInstance#ROOT/StandardCimv2/MSFT_NetAdapter

# Alternativ werden nur die Eigenschaften der Instanz der Netzwerkkarte "Ethernet" mit folgendem Befehl angezeigt:

Get-NetAdapter -Name Ethernet | format-list * 
