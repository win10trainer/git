﻿<# Legen Sie eine Variable $note an und weisen Sie ihr einen Wert zwischen 1 und 6 zu. Verwenden Sie die
Switch-Anweisung, um für die Werte die entsprechenden Texte gemäß der folgenden Tabelle auszugeben:
Note   Text
1      sehr gut
2      gut
3      befriedigend
4      ausreichend
5      mangelhaft
6      ungenügend
Experimentieren Sie mit verschiedenen Eingabewerten.#>

$note = get-random -Maximum 7 -Minimum 0 #Zufallsgenerierte Zahlenwerte zum Experimentieren



# Programmieren Sie eine Schleife, die die Werte 10 bis 100 in Zehnerschritten ausgibt

