﻿# Dateivorgänge

# Erstellen eines Ordners C:\data1 und eines Ordners C:\data2, vorher prüfen ob schon vorhanden

 

 

# Erstellen der Dateien Daten1.txt, Daten2.txt, daten3.txt, testbatch.bat in C:\data1
# Vorher prüfen, ob schon verhanden







# Auflisten des Inhalts von Data1

 

# Auflisten nur der Batchdatei

   

# Auflisten aller Dateien ausser der Batchdatei (exclude filter verwenden)

 

# Verschieben der Datei testbatch.bat in das Verzeichnis C:\data2

 

# Auflisten des Ordnerinhalts von data2

 

# Text "Dies ist ein Testtext" zu daten1.txt hinzufügen

 

# Auslesen des Textes

 

# Kopieren des Inhalts in Daten2.txt

 

# Auslesen des Inhalts von Daten2.txt Mit Pipeline get-content | add-content

 

# Löschen der Datei daten3.txt

 

# weitere Zeilen zu Daten1.txt hinzufügen:
# "Dieser Testtext wurde mit Powershell hinzugefügt"
# "Dazu wurde Add-Content verwendet"
# "Die Datei soll in der Freigabe \\server1\data gespeichert werden
#

  

# Herausfinden mit -match ob das Wort "Testtext" in der Datei" ist (get-content -path...)
# Weil mehrere Inputs eingegeben werden, wird die Zeile mit dem Match ausgegeben und nicht True
 

# Mit Select-String nach testtest suchen und mit select-object Zeilennummer und Tetxtzeile ausgeben

 
# Prüfen, mit -match und einer redular expression, ob ein Powershell cmdlet im Text stehen könnte (muster:verb-noun)
# Lesen Sie den Text über get-content ein
# Weil mehrere Inputs eingegeben werden, wird die Zeile mit dem Match ausgegeben und nicht True

 
# Info: Die Methode ismatch für eine Regex-Object kann mit der Option MultiLine damit umgehen und gibt nur True oder False aus
# $RX = [regex]::new("\w+-\w+","MultiLine")
# $RX.IsMatch((get-content -Path C:\data1\daten1.txt))

# Beispiel: Permanentes Ändern: Replace ändert nur in der Ausgabe, nicht aber den Inhalt
# Wird dir Änderung in einer Variable gespeichert, kann sie die Dateiinhalte überschreiben
# (get-content -Path C:\data1\daten1.txt) -replace "add-content","get-content"
# $Newcontent = (get-content -Path C:\data1\daten1.txt) -replace "add-content","set-content"
# Set-Content -Path C:\data1\daten1.txt -Value $Newcontent


