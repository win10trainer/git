﻿#Listen Sie alle WMI-Klassen auf, die sich unter root\cimv2 befinden



# Finden Sie heraus, welche davon mit dem BIOS zu tun haben



# Ermitteln Sie die BIOS-Daten des Computers dc

 
# Ermittel Sie die Klasse, die sich mit logischen Datenträgern (LogicalDisk)beschäftigt

 
# Listen Sie mittels der gefundenen WMI-Klasse die betreffenden Daten des lokalen Computers auf 
 
# Filtern Sie die Daten so, dass nur die internen Festplattenlaufwerke (DriveType 3) angezeigt werden und
# geben Sie die Geräte-ID, den freien Speicherplatz und die Gesamtgrösse an

 
# Listen Sie den Namespace root/cimv2 auf mit Hilfe des Get-CimClass CmdLets
 

# Ermitteln Sie die Eigenschaften der internen Festplatte (drivetype ist 3) Win32_logicalDisk 
# mit Hilfe von Get-CimInstance mit einem Filter (-Filter). Der Filter verwendet die WMI Sysntax!
 

# Welche CIM-Klasse zeigt die BIOS Daten an ?


