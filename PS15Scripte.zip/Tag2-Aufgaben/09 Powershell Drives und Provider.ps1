﻿# Zeigen Sie die vorhanden Powershell Provider auf

 

# Erstellen Sie einen neuen PowershellDrive "Windows", der das Windowsverzeichnis
# bereitstellt

 

# Wechseln Sie in den Drive

 

# Zeigen Sie die versteckten Inhalte an

 

# Zeigen Sie die Inhalte an die sowohl versteckt als auch Systemdaten darstellen
 

# Wechseln Sie zum PSDrive HKLM des Registry-Providers

 
# Was gibt es hier? Zeigen Sie an, was in HKLM liegt.

 

# Wechseln Sie in den Hardwarezweig
 

# Alles darin auflisten (rekursives Auflisten)

 

# Direkter Wechsel in den Benutzerzweig HKCU\Control Panel\Colors

 

# Was gibt es hier (Colors ist ein Item, die Inhalte sind Properties mit Values)

 

#Speichern Sie den Wert von ActiveBorder in der Variablen AB. Zeigen Sie anschliessend den Inhalt von AB an
 

# Ändern Sie den Registryeintrag ActiveBorder zu Wert "60 60 60"
# Active Borders ist eine Property von Colors und hat einen Wert
# Zeigen Sie den neuen Wert an

 

# Setzen Sie den Wert von ActiveBorder auf den Wert von $AB

 


# Wechseln Sie zurück ins Dateisystem ins Wurzelverzeichnis vonn C

 


# Listen Sie den Inhalt auf

 

# Erstellen Sie den Ordner C:\test. Der Wert itemtype muß angegeben werden

 

#Bevor man den Ordner erstellt, kann man testen ob er schon existiert. Verwenden Sie das
#  Verwenden Sie das Test-Path CmdLet um zu testen, ob Ihr Ordner C:\test schon existiert

 

# Prüfen Sie ob es einen C:\test2 ordner gibt. Wenn nicht erstellen Sie ihn
 

# Erstellen Sie in Test eine bat,txt und eine ps1 Datei

New-Item -Path C:\TEST -Name Testfile.txt -ItemType file -Value "Inhalt Blaaa"
New-Item -Path C:\TEST -Name Testfile.ps1 -ItemType file -Value "Get-service"
New-Item -Path C:\TEST -Name Testfile.bat -ItemType file -Value "dir"

 

# wechseln Sie in den WSMAN Powershell-Provider
 
# Wechseln Sie in den Pfad .\localhost\Client
 
# Zeigen Sie den Inhalt an
 

#TrustedHosts Liste bearbeiten: Bearbeiten Sie das Item TrustedHosts
# indem Sie die Adresse "10.0.0.10" eintragen
 
# Zeigen Sie die Adresse in der TrustedHosts Liste an
 