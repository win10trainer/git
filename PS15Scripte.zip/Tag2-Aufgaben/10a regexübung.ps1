﻿# Regex Übung
# Finden Sie ein Pattern, das das Muster eines UNC Pfades, z.B. \\server1\freigabe, identifizert
# testen Sie an:



"\\server44\daten" -match 
"\server\\daten"  -match 
"\\server\\daten"  -match 
"\\server-daten" -match 
"\\123\daten" -match 

#Optional: Zahlen am Anfang des Servernamens sind nicht zulässig, folgende schon. Wie sieht das Pattern aus
# bei dem vermieden wird, dass eine Zahl vorne steht.


# Finden Sie ein Pattern das herausfindet, ob eine Email Adresse nach der syntax olga.mueller@dieeinefirma.de geschrieben ist,
# wobei am Ende der Adresse .de .com und .net stehen darf.
# testen Sie an

 

"olga.mueller@dieeinefirma.de" -match 
"olga.mueller@dieeinefirma.org" -match 
"olga.mue.ller@dieeinefirma.de" -match 
"olga.mueller@@dieeinefirma.de" -match 
# Bei ein oder zwei punkten kann der optionale Punkt mit Fragezeichen als optional gekennzeichnet werden
"olga.mueller@die.einefirma.de" -match  