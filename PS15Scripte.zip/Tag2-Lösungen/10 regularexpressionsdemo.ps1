﻿# -match

# -match vergleicht das Auftreten der  Regular Expression in einer Zeichenfolge
"Donald Duck" -match "Donald" # True: Die Zeichenfolge Donald ist im Vergleichstring enthalten


"MacDonald" -match "Donald" # True: Die Zeichenfolge Donald ist im Vergleichstring enthalten

# Ankerzeichen ^ und $
# Wenn aber Donald am Anfang stehen soll, dann möchte ich, dass MacDonald nicht True sondern False ergibt
# Das Zeichen ^ kennzeichnet in einer Regular Expresion den Beginn einer Zeichenfolge, das Zeichen $ das Ende

"MacDonald" -match "^Donald" # False: Die Zeichenfolge Donald ist im Vergleichstring enthalten, aber nicht am Anfang

"Donald Duck" -match "Donald" # True: Die Zeichenfolge Donald ist im Vergleichstring enthalten und steht am Anfang

"Donald Duck" -match "Duck$" # True: Die Zeichenfolge Duck ist im Vergleichstring enthalten und steht am Ende

# Gruppieren und Oder-Bedingung
# Mit runden Klammern wird eine Zeichengruppe bestimmt
# mit dem Pipezeichen | wird eine Oder-Bedingung festgelegt

"Donald Duck" -match "(nal)" # die Zeichengruppe nal ist enthalten

"Haus" -match "h|l|maus"
"Maus" -match "h|l|maus"
"Laus" -match "h|l|maus" # alle drei Vergleich treffen zu
"laus","maus","klaus" -match "h|l|maus" # Statt true oder false gibt es die Ausgabe der Matches

# Gruppen und die Oder-Bedingung können aber zusammen gut eingesetzt werden

"Lon-DC1" -match "^(lon)|(syd)|(Muc)-"
"syd-SVR2" -match "^(lon)|(syd)|(Muc)-"
"slm-dc5"  -match "^(lon)|(syd)|(Muc)-" # slm entspricht nicht den 3 Gruppen
"balLon-DC1" -match "(lon)|(syd)|(Muc)-" # Oh, das Floating.. Trifft zu ohne Anchor


# Sonderzeichen .
# Das Sonderzeichen . steht für jedes beliebige einzelne Zeichen
"Donald" -match ".onald" # True, denn vor dem onald steht ein einzelnes Zeichen
"Ronald" -match ".onald" # True, denn vor dem onald steht ein einzelnes Zeichen
"Chronald" -match ".onlad" # False, denn es stehen 2 Zeichen vor dem onald, nicht nur 1 Zeichen

# Sonderzeichen *
# Das Sonderzeichen * steht dafür, dass das vorhergehende Zeichen keinmal oder beliebig oft folgt

"rom" -match "ro*m" # True, hier ist ein o vorhanden
"rm" -match "ro*m" # True, denn das o kann keinmal oder einmal oder mehrfach auftreten, hier keinmal
"room" -match "ro*m" # True, hier folgt ein weiteres o
"rooooooommmmm" -match "ro*m" # Die zeichenfolge roooooom ist enthalten
"strom" -match "ro*m" # True: Die zeichenfolge rom entspricht der gesuchten Zeichenfolge

# Das Sonderzeichen ?
# Bei ? kann das vorhergehende Zeichen nicht oder genau einmal auftreten

"rm" -match "ro?m" # True, das o tritt hier keinmal auf
"rom" -match "ro?m" # True, das o tritt genau einmal auf
"room" -match "ro?m" # False, hier folgt ein weiteres o und o tritt nicht keinmal oder einmal sondern zweimal auf
"room" -match "ro?o?m" # True, es gibt im Vergleich jeweils 1 o
"rom" -match "ro?o?m" # Ebenfalls true. Das erste o ist ein einmaliges o, das zweite o ist nicht vorhanden, tritt keinmal auf
"rm" -match "ro?o?m" # Ebenfalls true, die Zeichen o treten jeweils beidesmal keinmal auf..

# Escaping / Maskieren
# Wie kann ich aber die Sonderzeichen als normale Zeichen verwenden, zum Beispiel in einer Rechnformel das Malzeichen * prüfen?
# Dazu wird das Sonderzeichen mit einem Backslash \ maskiert und als normales Zeichen interpretiert. Der Backslash wird ebenfalls
# mit einem Backslash maskiert.

"5*5" -match "\*" # Die Zeichenfolge enthält ein * Zeichen

"Wie heissen Sie?" -match "\?$" # Am Ende muss ein Fragezeichen stehen

"Der Satz ist hier zuende." -match "\.$" # Am Ende soll ein Punkt stehen

# Powerpoint Präsentation


# Wertebereiche und Zeichenlisten
# Sollen an einer Stelle bestimmte, aber verschiedene Werte stehen können, kommt ein Bereich in Frage
# [abc] a,b oder c können keinmal,einmal oder mehrfach vorkommen, [a-z] alle Buchstaben zwischen a und z können vorkommen
# Der Sonderfall [^abc] sagt aus, dass diese Zeichen nicht vorkommen dürfen.

"Haus" -match "[H,R]aus"
"Raus" -match "[H,R]aus"
"Laus" -match "[H,R]aus" # Das L ist nicht in der Liste
"Laus" -match "[^H,R]aus" # Das L darf vorkommen, aber nicht H oder R

"Klaus" -match "[H,R,K,L]aus" # Sowohl K als auch L sind in der Liste

"Klaus" -match "[H,R,K,L]aus" # Sowohl K als auch L sind in der Liste
 
 # Vergleich mit der Oder-Bedingung
 "Klaus" -match "h|k|l|raus" # Gleiches Ergebnis


# Die Zeichenlisten und Bereiche sind relativ aufwendig
# Mit Zeichenklassen können Zeichentype identifiziert werden
# \w alphanumerisches Zeichen
# \W nicht-alphanumerisch
# \s Leerzeichen
# \S kein Leerzeichen
# \d Ziffer
# \D keine Ziffer
# \n newline
# \r carrige return
# \t tabulator




# Ein + Zeichen dahinter sagt aus, das dieser Zeichentyp mehrfach auftreten darf. 
# Ein folgendes Zeichen anderen Typs 
# unterbricht den Vergleich für diesen Teil der Abfrage


"user@adatum.com" -match "\w+@\w+\.\w+" # True

"agatha.christie@krimis.de" -match "\w+@\w+\.\w+" # Ebenfalls True. Die Abfrage wird ab dem ersten Punkt erfüllt
"agatha.christie@krimis.de" -match "^\w+@\w+\.\w+" # Die Abfrage gibt False, da beim Punkt die Bedingung noch nicht erfüllt ist.
"agatha.christie@krimis.de" -match "^\w+\..\w+@\w+\.\w+" # Die Abfrage gibt True. der Punkt wurde benannt und dass alphanumerische Zeichen folgen
"user@krimis.de" -match "^\w+\.?\w+@\w+\.\w+" # Die Abfrage gibt True. der Punkt wurde benannt aber ist nicht notwenig und alphanumerische Zeichen folgen
"user@krimis@.de" -match "^\w+\.?\w+@\w+\.\w+" # Die Abfrage gibt False.Das zweite @ ist nicht alphanumerisch

# Man kann auch die Häufigkeit der Übereinstimmungem untersuchen. Dazu werden geschweiftw Klammern verwendet
# {3} es dürfen genau drei übereinstimmungen sein
# {2,3} es dürfen 2 oder 3 übereinstimmungen sein, nicht aber mehr oder weniger
# {2,} es müssen mindestens 2 Übereinstimmungen sein, aber es können beliebig mehr sein


"abcd" -match "\w{3}" # genau 3 Zeichen sind drin in abc
"abcd" -match "^\w{3}$" # hier sind aber zwischen Anfang und Ende 4 und nicht 3 Zeichen

"1234" -match "^\d{3,4}$"  # True
"12345" -match "^\d{3,4}$" # False

# Select-String
# Neben Match gibt es noch andere Powershell Operators, die ähnliche Funktionen bieten:

(get-content C:\data1\daten1.txt) | select-string "Freigabe" # Sucht nach Strings und gibt Zeile aus

(get-content C:\data1\daten1.txt) | select-string "Freigabe" | get-member | select -Property name

(get-content C:\data1\daten1.txt) | select-string "Freigabe" | Select-Object LineNumber, Line

# Ausgabe nur der Worte, die dem Muster entsprechen
(get-content C:\data1\daten1.txt) | select-string -Pattern "\w+-\w+" | foreach {($_.matches).value}


# Split-Operator

"192.168.2.99" -split "\."

$unc = ("\\server1\daten" -split "\\")

# Regular Expression Object hat die Methoden ist aber Case-Sensitive, wenn man es nicht abschaltet
# Macht bei diesem Vergleich nichts aus

$RXS = [regex]::new("\\","IgnoreCase")
$rxs.Split("\\server1\daten")

# Replace

"Alle meine Entchen schwimmen auf dem See" -replace "Entchen","Gänse"
