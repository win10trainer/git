﻿#Mit welchem Befehl aktivieren Sie das Powershell Remoting?
#Enable-PSRemoting -Force -Confirm:$false

# Ermitteln Sie die laufenden Prozess auf DC (mit dem -computername Parameter)

Get-Process -ComputerName DC

# Ermitteln Sie die laufenden Dienste auf DC (mit invoke-command). Filtern Sie das Ergebnis im Scriptblock nach laufenden Diensten.

Invoke-Command -ComputerName DC -ScriptBlock { Get-Service | Where-Object Status -eq "running"}

# Ermitteln Sie die Dienste auf DC (mit dem -computername Parameter). Filtern Sie das von DC erhaltene Ergebnis nach laufenden Diensten 

Get-Service -ComputerName DC | Where-Object status -eq "running"

# Untersuchen Sie beide Ergebnisse mit get-member. Wo ist der Unterschied? Welche Methoden kann man anwenden?
Invoke-Command -ComputerName DC -ScriptBlock { Get-Service | Where-Object Status -eq "running"} | Get-Member
Get-Service -ComputerName DC | Where-Object status -eq "running" | Get-Member


# Erstellen eine Sitzungsvariable $Session für die Remoteverbindung zu DC

$session = New-PSSession -ComputerName DC

# Lassen Sie sich alle Sitzungen anzeigen



# ----------------------INFO:-----------------------------------------------------------------------------------------
# Sie mussten sich nicht gesondert authentifizieren, weil Ihre Anmeldeeigenschaften weitergereicht wurden.
# Sie können alternative Anmeldeinformationen mit dem Schalter -credential angeben. Mit 
# $cred = Get-Credential -Credential seminar\administrator können Sie diese Anmeldeinformationen in einer Variablen speichern.
# --------------------------------------------------------------------------------------------------------------------

# öffnen Sie die Remotesitzung mit DC. Verwenden Sie die Variable $session 

Enter-PSSession -Session $session


# Ermitteln Sie die laufenden Prozesse und die laufenden Dienste und verlassen Sie die Sitzung
# Befehle in der Sitzung:
Get-Process
Get-Service
exit

# Entfernen Sie die Sitzung unter Verwendung der Variable $session

Remove-PSSession -Session $session


#Erstellen Sie eine Textdatei mit dem Inhalt get-service und speichern Sie sie unter C:\service.ps1.
# 
# Führen Sie das Script remote auf DC aus indem Sie das CmdLet invoke-command nutzen
New-Item -Path C:\ -Name Service.ps1 -ItemType File -Value "Get-Service" -Force
Invoke-Command -ComputerName DC -FilePath C:\Service.ps1



# Implizites Remoting als Beispiel. Führen Sie die einzelnen Zeilen aus
# Der lokale (!) Rechner muß RemoteScripte ausführen können

Set-ExecutionPolicy Unrestricted
$session = new-pssession -ComputerName DC

Invoke-Command -Session $session -ScriptBlock { import-module Activedirectory} #läd das Modul
Import-PSSession -Session $session -Module ActiveDirectory -Prefix Rem #importiert das modul
Get-RemADComputer -Filter * #modul benutzen
Get-PSSession

exit


