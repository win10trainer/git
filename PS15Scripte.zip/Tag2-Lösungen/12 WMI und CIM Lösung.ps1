﻿#Listen Sie alle WMI-Klassen auf, die sich unter root\cimv2 befinden

Get-WmiObject -Namespace root\CIMv2 -list

# Finden Sie heraus, welche davon mit dem BIOS zu tun haben

Get-WmiObject -Namespace root\CIMv2 -list | where name -like "*bios*"

# Ermitteln Sie die BIOS-Daten des Computers dc1

Get-WmiObject -Class win32_bios -ComputerName dc1

# Ermittel Sie die Klasse, die sich mit logischen Datenträgern (LogicalDisk)beschäftigt

Get-WmiObject -Namespace root\CIMv2 -list | where name -like "*logicaldisk*"

# Listen Sie mittels der gefundenen WMI-Klasse die betreffenden Daten des lokalen Computers auf 
Get-WmiObject -Class win32_logicaldisk

# Filtern Sie die Daten so, dass nur die internen Festplattenlaufwerke (DriveType 3) angezeigt werden und
# geben Sie die Geräte-ID, den freien Speicherplatz und die Gesamtgrösse an

Get-WmiObject -Class win32_logicaldisk | where drivetype -eq 3 | select deviceid, freespace, Size

# Listen Sie den Namespace root/cimv2 auf mit Hilfe des Get-CimClass CmdLets
Get-CimClass -Namespace root/cimv2

# Ermitteln Sie die Eigenschaften der internen Festplatte (drivetype ist 3) Win32_logicalDisk 
# mit Hilfe von Get-CimInstance mit einem Filter (-Filter). Der Filter verwendet die WMI Sysntax!
Get-CimInstance -ClassName Win32_LogicalDisk -Filter "drivetype = 3" # WMI-Filter, verwendet nicht die Powershell Vergleichsoperatoren!!

# Welche CIM-Klasse zeigt die BIOS Daten an ?
Get-CimInstance -ClassName CIM_BIOSElement
 