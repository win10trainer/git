﻿<# Legen Sie eine Variable $note an und weisen Sie ihr einen Wert zwischen 1 und 6 zu. Verwenden Sie die
Switch-Anweisung, um für die Werte die entsprechenden Texte gemäß der folgenden Tabelle auszugeben:
Note   Text
1      sehr gut
2      gut
3      befriedigend
4      ausreichend
5      mangelhaft
6      ungenügend
Experimentieren Sie mit verschiedenen Eingabewerten.#>

$note = get-random -Maximum 7 -Minimum 0
switch ($note){
1 {Write-Host "$note ist Sehr gut"}
2 {Write-Host "$note ist Gut"}
3 {Write-Host "$note ist Befriedigend"}
4 {Write-Host "$note ist Ausreichend"}
5 {Write-Host "$note ist Mangelhaft"}
6 {Write-Host "$note ist Ungenügend"}
default {Write-Host "$note gibt es garnicht.."}
}


# Programmieren Sie eine Schleife, die die Werte 10 bis 100 in Zehnerschritten ausgibt

for ($i=10;$i -le 100;$i +=10){ $i }