﻿# Zeigen Sie die vorhanden Powershell Provider auf

Get-PSProvider

# Erstellen Sie einen neuen PowershellDrive "Windows", der das Windowsverzeichnis
# bereitstellt

New-PSDrive -Name "Windows" -PSProvider FileSystem -Root C:\Windows

# Wechseln Sie in den Drive

Set-Location WINDOWS:

# Zeigen Sie die versteckten Inhalte an

Get-ChildItem -Hidden
Get-ChildItem -Attributes h

# Zeigen Sie die Inhalte an die sowohl versteckt als auch Systemdaten darstellen
Get-ChildItem -Hidden -System
Get-ChildItem -Attributes h+s


# Wechseln Sie zum PSDrive HKLM des Registry-Providers

Set-Location HKLM:

# Was gibt es hier? Zeigen Sie an, was in HKLM liegt.

Get-ChildItem -path .\

# Wechseln Sie in den Hardwarezweig

Set-Location -Path .\HARDWARE

# Alles darin auflisten (rekursives Auflisten)

Get-ChildItem -Path .\ -Recurse

# Direkter Wechsel in den Benutzerzweig HKCU\Control Panel\Colors

Set-Location 'HKCU:\Control Panel\Colors'


# Was gibt es hier (Colors ist ein Item, die Inhalte sind Properties mit Values)

Get-ItemProperty -Path .\

#Speichern Sie den Wert von ActiveBorder in der Variablen AB. Zeigen Sie anschliessend den Inhalt von AB an

$AB = Get-ItemPropertyValue -Path .\ -Name ActiveBorder
$AB

# Ändern Sie den Registryeintrag ActiveBorder zu Wert "60 60 60"
# Active Borders ist eine Property von Colors und hat einen Wert
# Zeigen Sie den neuen Wert an

Set-ItemProperty -Path .\ -Name ActiveBorder -Value "60 60 60"
Get-ItemPropertyValue -path .\ -Name ActiveBorder

# Setzen Sie den Wert von ActiveBorder auf den Wert von $AB

Set-ItemProperty -Path .\ -Name ActiveBorder -Value $AB


# Wechseln Sie zurück ins Dateisystem ins Wurzelverzeichnis vonn C

Set-Location -Path C:\


# Listen Sie den Inhalt auf

Get-ChildItem -Path .\


# Erstellen Sie den Ordner C:\test. Der Wert itemtype muß angegeben werden

New-Item -path c:\ -Name TEST -ItemType Directory

#Bevor man den Ordner erstellt, kann man testen ob er schon existiert. Verwenden Sie das
#  Verwenden Sie das Test-Path CmdLet um zu testen, ob Ihr Ordner C:\test schon existiert

Test-Path -Path C:\TEST

# Prüfen Sie ob es einen C:\test2 ordner gibt. Wenn nicht erstellen Sie ihn
Test-Path C:\Test2
new-item -path C: -Name Test2 -ItemType directory

# Erstellen Sie in Test eine bat,txt und eine ps1 Datei

New-Item -Path C:\TEST -Name Testfile.txt -ItemType file -Value "Inhalt Blaaa"
New-Item -Path C:\TEST -Name Testfile.ps1 -ItemType file -Value "Get-service"
New-Item -Path C:\TEST -Name Testfile.bat -ItemType file -Value "dir"

# Kopieren Sie die bat und txt Dateien in einem Befehl in das Verzeichnis Test2 
copy-item -Path C:\TEST\*.* -Destination C:\test2 -Exclude *.ps1 -Force

# wechseln Sie in den WSMAN Powershell-Provider
Set-Location WSMAN:
# Wechseln Sie in den Pfad .\localhost\Client
Set-Location .\localhost\Client
# Zeigen Sie den Inhalt an
Get-ChildItem -Path .\

#TrustedHosts Liste bearbeiten: Bearbeiten Sie das Item TrustedHosts
# indem Sie die Adresse "10.0.0.10" eintragen
Set-Item -Path .\TrustedHosts -Value "10.0.0.100"
# Zeigen Sie die Adresse in der TrustedHosts Liste an
$Value = Get-Item -Path .\TrustedHosts | select -ExpandProperty value