﻿get-date
(get-date).ToShortDateString()
(get-date).ToLongDateString()
(get-date).ToShortTimeString()
(get-date).ToLongTimeString()

(get-date).AddDays(-7)
(get-date).AddDays(-7).DayOfWeek

get-date -format "dddd dd. MMMM HH:mm:ss 'Uhr'"

New-TimeSpan -Start (get-date) -End ("31.12.2020")
(New-TimeSpan -Start (get-date) -End ("31.12.2020")).Days
(New-TimeSpan -Start (get-date) -End ("31.12.2020")).TotalHours
(New-TimeSpan -Start (get-date) -End ("31.12.2020")).TotalHours -as [int]

(New-TimeSpan -Start (get-date) -End ("23:15"))

# https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/get-date?view=powershell-7https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/get-date?view=powershell-7