﻿
# Ermitteln Sie die Eigenschaften und Methoden von Gruppen des Active Directory

Get-ADGroup -Filter * | get-member

# listen Sie die vorhanden Gruppennamen und deren Gruppenbereich auf

Get-ADGroup -Filter * | select name,Groupscope

# Listen Sie nur Globale AD Sicherheitsgruppen mit Namen,Bereich und Category auf

Get-ADGroup -Filter * | Where-Object {$_.groupcategory -eq "Security" -and $_.GroupScope -eq "Global"} | select name,Groupcategory,GroupScope

# Erstellen  Sie eine neue globale Sicherheitgruppe Marketing in der OU Marketing

New-ADGroup -Name "Marketing" -GroupScope Global -GroupCategory Security -Path "OU=marketing,DC=seminar,DC=local"

# Erstellen Sie auf gleiche Weise die Gruppen für Marketing Sued und Nord
new-ADGroup -Name "Marketing Sued" -GroupScope Global -GroupCategory Security -Path "OU=Marketing Sued,OU=Marketing,DC=seminar,DC=local"
new-ADGroup -Name "Marketing Nord" -GroupScope Global -GroupCategory Security -Path "OU=Marketing Nord,OU=Marketing,DC=seminar,DC=local"

# Fügen Sie die Marketing Sued und die Marketing Nord Gruppe als Mitglieder in die Gruppe Marketing auf

Add-ADGroupMember -Identity "Marketing" -Members "Marketing Sued","Marketing Nord"

# Prüfen Sie die Mitgliedschaft in der Marketinggruppe und zeigen Sie nur die Mitgliedernamen an
Get-ADGroupMember -Identity "Marketing" | select name

# Otto Hering gehört in die Gruppe Marketing Nord, fügen Sie ihn als Mitglied hinzu.

Add-ADGroupMember -Identity "Marketing Nord" -Members "Otto.Hering"

# Prüfen Sie die Mitgliedschaft von Otto Hering in der Gruppe

Get-ADGroupMember -Identity "Marketing Nord" | select name

# prüfen Sie die Gruppenmitgliedschaften von Marketing rekursiv und geben Sie nur die Mitgliedernamen aus

Get-ADGroupMember -Identity "Marketing" -Recursive | select name

# Erstellen Sie die globale Sicherheitsgruppe Manager und nehmen Sie alle Benutzer auf, die CEO oder Leiter oder Leiterin sind (Eigenschaft: title)

New-ADGroup -Name "manager" -GroupCategory Security -GroupScope Global

Add-ADGroupMember -Identity "manager" -Members (Get-ADUser -Filter * -Properties title| Where-Object {$_.title -like "*leit*" -or $_.title -like "ceo"})

# prüfen Sie sdie Mitgliedschaft in dieser Gruppe

Get-ADGroupMember -Identity "manager" | select name

# Erstellen Sie eine globale Gruppe aller Benutzer mit dem Title Angestellter mit dem Namen Angestellte

New-ADGroup -Name Angestellte -groupscope global
 
# Nehmen Sie alle benutzer mit dem Title Angesteller oder Angestellte in die Gruppe auf

Add-ADGroupMember -Identity "Angestellte" -Members (Get-ADUser -Filter * -Properties title | where {$_.title -like "Angestell*"})






