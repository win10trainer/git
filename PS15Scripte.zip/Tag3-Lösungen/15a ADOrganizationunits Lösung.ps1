﻿# Listen Sie die CmdLets des Modules ActiveDirectory auf
get-command -Module ActiveDirectory

# Mit welchem Befehl kann man Organisationseinheiten erstellen? 
# Erstellen Sie die OU Marketing im Stamm der Domäne mit der Beschreibung "Marketing OU"
# Ermöglichen Sie das Löschen der Organisationseinheit (-ProtectedFromAccidentalDeletion $false)

New-ADOrganizationalUnit -Name Marketing -Description "Marketing OU" -Path "DC=seminar,DC=local" -ProtectedFromAccidentalDeletion $false

# Zeigen Sie nur die Marketing OU an

Get-ADOrganizationalUnit -filter {name -eq "Marketing"}

# Erstellen Sie in der Marketing OU die Unterorganisationseinheiten "Marketing Sued" und "Marketing Nord" sowie "Online Marketing" ohne Schutz vor versehentlichem Löschen

New-ADOrganizationalUnit -Name "Marketing Sued"  -Path "OU=marketing,DC=seminar,DC=local" -ProtectedFromAccidentalDeletion $false
New-ADOrganizationalUnit -Name "Marketing Nord"  -Path "OU=marketing,DC=seminar,DC=local" -ProtectedFromAccidentalDeletion $false

# Erstellen Sie die Organisationseinheiten Management und IT im Stamm der Domäne 
New-ADOrganizationalUnit -Name "Management"  -Path "OU=Management,DC=seminar,DC=local"
New-ADOrganizationalUnit -Name "IT"  -Path "OU=IT,DC=seminar,DC=local"


# Zeigen Sie die OUs an, die in der OU Marketing liegen und geben Sie nur die Namen an. Verwenden Sie searchbase und searchscope

Get-ADOrganizationalUnit -Filter * -SearchBase "OU=marketing,DC=seminar,DC=local" -SearchScope onelevel | select name

# Zeigen Sie die Namen aller OUs der gesamten Domäne an und ihren Ldap-Pfad

Get-ADOrganizationalUnit -Filter * | Format-Table name,distinguishedname





