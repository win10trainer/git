﻿# erstellen Sie eine Funktion convert-InchToCm, die Inches in cm umwandelt. Der Inch-Wert soll als Parameter übergeben werden.



function  convert-InchToCm {

[cmdletbinding()]

           Param
              (
                                 
                # Hilfe:Parameter als Inchwert
                [Parameter(Mandatory=$true)]
                [double]$Inch
                          
                )
                          
               Begin
                    {
                    }
               Process
                      {
                          
                       $cm = $inch * 2.54

                       return $cm

                      }
                End
                    {
                    }
          } #end function



# Erstellen sie die Function run-HelpShowWindow, die mit einem cmdlet-Namen aufgerufen werden soll und
# dafür sorgt, dass für das CmdLet die Hilfe von Get-Help mit dem Parameter -Showwindows ausgeführt wird
#  Wenn Sie es können, versuchen Sie einen [ValidatePattern("")] im Parameterblock einzusetzen, das über-
# prüft, ob es sich um ein CmdLet handeln könnte (Muster: verb-noun)

function run-HelpshowWindow {

[CmdLetBinding()]

Param (

[Parameter(mandatory=$true)]
[Validatepattern("^\w+-\w+$")]
[string]$Cmdletname
)

Process
    {

    get-help $Cmdletname -ShowWindow

    }

}






