﻿
# Importieren Sie die Benutzer aus der CSV-Datei NeueUser.csv mit Hilfe des Scripts NeueUser.ps1
# Bearbeiten Sie dazu die Datei NeueUser.ps1 und tragen Sie den korrekten Pfad ein.
# Überprüfen Sie, ob die Benutzer auch erstellt wurden. Zeigen Sie einfach alle Benutzer der Domäne an.

Get-aduser -filter *

# Ermitteln Sie die Eigenschaften und Methoden des Befehls get-aduser mit dem CmdLet get-member

Get-Aduser -Filter *  -Properties * | get-member

# Ermitteln Sie alle aktuell vorhandenen User und geben Sie nur die Namen aus

Get-ADUser -Filter * | select name

# Ermitteln Sie alle deaktivierten Benutzerkonten und geben Sie Namen und Status aus

get-aduser -filter * | where {$_.enabled -eq $false} | select name,enabled

Search-ADAccount -Accountdisabled -UsersOnly

# Geben Sie nur Benutzer aus, die mit "adm" beginnen, wobei auch der Wert von Department angezeigt werden soll.

get-aduser -filter {name -like "adm*"} -Properties Department

# Aktivieren Sie das Konto Gast, prüfen Sie den Status und deaktivieren Sie es wieder

set-aduser -Identity Gast -Enabled $true
get-aduser -Identity Gast -Properties enabled | select name,enabled
set-aduser -Identity Gast -Enabled $false


# Erstellen Sie den Benutzer Hans Wurst mit dem Anmeldenamen HansW dem Wert "Marketing Sued" für die Abteilung in der entsprechenden OU. Hans Wurst
# hat den Titel Marketingleiter und sitzt in München. Er soll das Kennwort Pa$$w0rd verwenden, das Konto soll aktiviert sein.
# Das Kennwort muss ein secure string sein. Verwenden Sie Klartext (siehe oben)

new-aduser -Name "Hans Wurst" -SamAccountName "Hans.Wurst" -UserPrincipalName "Hans.Wurst@seminar.local" -City "München" -AccountPassword (ConvertTo-SecureString "Passw0rd" -asplaintext -force) -Enabled $true -Path "OU=Marketing Sued,OU=marketing,DC=seminar,DC=local"

# Melden Sie sich mit dem neuen Konto am Client an und dann wieder als ps\administrator

# Ändern Sie das Kennwort von Hans Wurst auf Passw0rd1

Set-ADAccountPassword -Identity "Hans.Wurst" -Reset -NewPassword (ConvertTo-SecureString "Passw0rd1" -asplaintext -force)


# Ergänzen Sie die Daten von Hans Wurst mit der 
# Büro-Telefonnummer 030 311311 (officePhone)
# und der Mobilnummer 015258408442 (MobilePhone)

set-aduser -Identity "Hans.Wurst" -OfficePhone "030 311311" -MobilePhone "015258408442"

# Prüfen Sie diese Werte bei Hans

get-aduser -Identity "Hans.Wurst" -Properties Mobilephone,officephone | select name,officephone,mobilephone

# Verschieben Sie Hans Wurst aus der aktuellen OU in die OU Management

Move-ADObject (get-aduser -Identity "hans.wurst") -TargetPath "OU=management,DC=seminar,DC=local"

# Setzen Sie das Ablaufdatum des Kontos Karin.Ahnungslos auf den morgigen Tag
Set-Aduser -identity "Karin.Ahnungslos" -AccountExpirationDate ((get-date).AddDays(1)) -confirm:$false

# Suchen Sie nach Benutzern, deren Konto innerhalb von 14 Tagen abläuft

Search-ADAccount -AccountExpiring -TimeSpan "14.00:00:00"

# Suchen Sie nach Benutzern, die seit 30 Tagen inaktiv waren

Search-ADAccount -AccountInactive -TimeSpan "30.00:00:00"

# Suchen Sie nach Konten, die sich noch nie angemeldet haben. Logoncount ist dann 0 (Null). Geben Sie den Namen aus

Get-ADUser -Filter *  -Properties LogonCount | where LogonCount -eq 0 | select name

