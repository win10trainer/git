﻿# Erstellen Sie eine Variable mit New-Variable, eine Konstante und erstellen Sie mit Get-Process eine Variable, die das Ergebnis
# von Get-Process speichert

New-Variable -Name V1 -Value "abc" -Description "Meine neue Variable V1"
New-Variable -Name const1 -Value 42 -Option Constant
Get-Process -OutVariable Processes | out-null


# Erstellen Sie eine Vaiable $var1 mit dem Wert 1, $var2 mit dem Wert "b" und eine Variable 
# $var3 mit dem Ergebnis des Cmdlets get-Process
$var1 = 1 ;$var2 = "b";$var3 = Get-Process

 
# Ermittel Sie den Variablentyp mit der Methode .GetType() für die drei Variablen.


$var1.GetType();$var2.GetType();$var3.GetType()
#
# Anmerkung: Variable var3 ist ein Array aus Objekten

# Addieren Sie Variable $var1 mit $var2. Geht das? Ergebnis?

$var1 + $var2

# Antwort: Nein, eine Zahl kann nicht mit einem String addiert werden

# Addieren Sie $var2 mit $var1. Geht das? Ergebnis?
 $var2 + $var1

# Antwort: Ja, Ein String kann mit einer Zahl addiert werden. Die Zahl wird dabei zum String konvertiert.

#Das [int] erzwingt die Eingabe einer Zahl. Deklarieren Sie den Variblentyp von $var4 als
# [int] und versuchen Sie den Wert "b" zuzuweisen.Geht das?

[int]$var4 = "b"

# Antwort: Nein, die Variable kann nur einen Integerwert aufnehmen


# Speichern Sie das Zeichen Nr. 33 in der Variablen $var5. Deklarieren Sie die Variable dazu als
# Variable vom Typ [char]. Geben Sie die Variable aus. Welches Zeichen ist gespeichert?

[char]$var5 = 33 ; $var5

# Antwort: Das ergibt ein Ausrufezeichen (ASCII Code 33)

# Speichern Sie den Wert 123 als [String] in der Varaiable $var5, ermitteln Sie den Typ und geben Sie
# den Inhalt der Variablen aus

[String]$var5 = 123 ; $var5.GetType()

# Weisen Sie der Variablen $var6 den Wert 10, der Variablen $var7 den Wert 2 zu. Addieren Sie die Werte.
# Einfache Addition
$var6 = 10;$var7 = 2 ; $var6 + $var7

# Verketten Sie die Strings abc und def, die Sie den neuen Variablen $var8 und $var9 zugewiesen haben.

$var8 = "abc" ; $var9 = "def" ; $var8 + $var9 


# Geben Sie mit write-host den Text: Der Inhalt der Variablen $var8 ist abc aus.
# Verwenden Sie doppelte Anführungszeichen, danach einfache Anführungszeichen, um den Text zu begrenzen.
# Was ist der Unterschied?

Write-Host "Der Inhalt der Variablen $var8 ist abc aus"
Write-Host 'Der Inhalt der Variablen $var8 ist abc aus'


# Antwort: Mit doppelten Ausrufezeichen wird der INHALT der Variablen ausgegeben
# Antwort: Mit einfachen Anführungszeichen wird der .NAME. der Variablen ausgegeben


# Maskieren Sie das $-Zeichen der Variablen mit einem Backtick ( `$var8 )
# und geben Sie den Text, begrenzt durch doppelte Anführungszeichen aus.
 Write-Host "Der Inhalt der Variablen `$var8 ist abc aus"

# Antwort: Mit dem Backtick wird der NAME der Variablen ausgegeben

# Weisen Sie der Variablen $var10 den Wert 4 und der Variablen $var11 den Buchstaben a zu.
 
 $var10 = 4 ; $var11 = "a"

# Multipizieren Sie $var10 mit $var11. Geht das? Ergebnis?
  $var10 * $var11

# Antwort: Nein, eine Zahl lässt sich nicht mit einem String multiplizieren

# Führen Sie die Multiplikation umgekehrt durch. Was passiert?

 $var11 * $var10
# Antwort: Der String wird entsprechend der Zahl mehrfach dargestellt

# Zeigen Sie den Wert 100 Mal an, der in $var11 gespeichert ist.
$var11 * 100

# Erstellen eines Arrays. Weisen Sie $var12 auf einmal die Werte 1,2,3 zu
 $var12 = 1,2,3

# Ermitteln Sie den Typ von $var12 und den Typ des ersten Elements in$var12

$var12.GetType() ; $var12[0]

# Entfernen Sie den Wert 2 aus dem Array

$var12 = $var12 -ne 2 ; $var12


# Erstellen Sie das Array $var13 mit den Werten "a","b","c"
 
 $var13 = "a","b","c"


# Ermitteln Sie den Typ des ersten Elements

$var13[0].GetType()

#Gemischter Inhalt: Weisen Sie dem Array $var14 die Werte 1 und "a" zu und
# ermitteln Sie den Typ des ersten Elements und zweiten Elements

$var14 = 1,"a"
$var14[0].GetType();$var14[1].GetType()



#Ermitteln der Sie die Anzahl der Arrayelemente in $var14 und $var13
$var13.Count;$var14.Count

#Fügen Sie das Zeichen b zum Array $var14 hinzu


$var14 += "b"

# Listen Sie den Inhalt von $var14 auf.
$var14


#Erzeugen Sie ein leeres Array $var15
$var15=@()


# Erstellen Sie folgendes Array $var16 $var16 = "server1","SeRver2","SERVER3"
# Manipulatuion der Ausgabe, nicht des Elementinhalts: Zeigen Sie den ersten Wert
# in Großbuchstaben an. Ändert sich der Inhalt von $var16[0] ?

$var16 = "server1","SeRver2","SERVER3"
$var16[0].ToUpper() ; $var16[0]

# Antwort: Nein, es wird nur die Anzeige in Grossbuchstaben durchgeführt.


# Hinzufügen von Elementen: Fügen Sie dem Array $var16 die Werte "server4" und "server5" hinzu
 
 $var16 += "server4","server5"


# Entfernen Sie den zweiten Wert aus dem Array und prüfen Sie das Ergebnis 

$var16 = $var16 -ne $var16[1]




# Entfernen Sie den Wert "server5" aus dem Array und prüfen Sie das Ergebnis

$var16 = $var16 -ne "server5" ; $var16

# Ersetzen eines Wertes: Ersetzen Sie im dritten Element "server" durch "client". Case sensitive!

$var16[2] = $var16[2].Replace("server","client") ; $var16[2]

#Anzahl der Elemente in einem Array: Ermitteln Sie die Anzahl der Eelemente im Array
$var16.Count
# Erstellen Sie eine leere ArrayList $AL. Der Typ ist: [System.Collections.ArrayList]
 [System.Collections.ArrayList]$al = @()


# Verwenden Sie die Methode .add() um client1, client3 und client2 als Werte in die Arraylist
# aufzunehmen (in der angegeben Reihenfolge!). Zeigen Sie die Arraylist an

 $al.add("client1")
 $al.add("client3")
 $al.Add("client2")
 


# Sortieren Sie die Arraylist und zeigen Sie sie an.

$al.sort()

# Anzeige in umgekehrter Folge.
$al.Reverse() ; $al

# Entfernen eines Elements: Entfernen Sie client3 mit der Methode .remove()

$al.Remove("client3")

# Fügen Sie an erster Stelle des Arrays den Wert client0 mit der Methode.insert() ein
$al.insert(0,"client0")
$al

#Hashtable: key - Value Zuordnung
# Geben Sie folgende Werte in einen Hashtable ein, wobei der Name der Key ist
# "Uschi" "040123456"
# "otto""0304575436";"Brian"="06955533"

$Hash1 = @{"Uschi"="040123456";"otto"="0304575436";"Brian"="06955533"}

#Anzeige der Werte zum Key:
$hash1.uschi

$hash1.otto

# Alle Keys und values
$hash1.Keys ; $hash1.Values

#Eintrag per key entfernen
$Hash1.Remove("otto")

# Eintrag hinzufügen: Der Key ist eindeutig und darf daher nur einmal vorhanden sein!
$hash1 += @{"rasputin"="99988877"}

# Werte suchen
$hash1.ContainsValue("99988877")
# Sortieren, aber nur zur Ausgabe, nicht in der Hashtabelle
$hash1.GetEnumerator() | Sort-Object -Property value
$hash1.GetEnumerator() | Sort-Object -Property key


###----------------------


# Alle Werte in einem Array zu Großbuchstaben machen:

$varX = "abc","DeF","Ghi"
$varX
for ($i = 0; $i -lt $varX.Count; $i++){ $varX[$i] = $varX[$i].toupper()}
$varX