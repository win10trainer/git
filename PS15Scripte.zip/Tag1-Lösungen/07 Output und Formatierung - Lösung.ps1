﻿# Zeigen Sie alle Befehle an, die das Verb out verwenden

Get-Command -Verb out
Get-Command out-*

# Was macht der Befehl out-null?

Get-Help Out-Null # Löscht die Ausgabe am Ende

# Drucken Sie das Ergebnisses der Befehlspipeline "get-service | format-table status,displayname"
# auf dem XPS Drucker aus. Ermitteln Sie zunächst den Druckernamen des XPS-Druckers.
# 1.Teilaufgabe: Ermitteln Sie die mit Druckern zusammenhängenden Cmdlets und dann den Druckernamen des XPS-Druckers.

Get-Command *printer*
Get-Printer




# 2. Befehl ausführen, Drucken Sie das Ergebnis von "get-service | format-table status,displayname" auf dem XPS Drucker aus

get-service | format-table status,displayname | Out-Printer -Name "Microsoft XPS Document Writer"

# Geben Sie für die Services alle Eigenschaften mit Out-Gridview aus. Verwenden Sie piplinen sie zu select-object * und von dort zu out-gridview

Get-Service | Select-Object * | Out-GridView
 

# Was erhalten Sie, wenn wenn Sie mit Format-table status,displayname formatieren und dann out-gridview verwenden?


Get-Service | Format-Table -Property Status,DisplayName | Out-GridView
## Antwort: Es gibt einen Fehler, da das Ergebnis des Format-Table nicht von Out-Gridview unterstützt wird



# Listen Sie die Dienste in einer Tabelle auf.

Get-Service | Format-Table
 

# Listen Sie die Dienste in einer Tabelle auf. Optimieren Sie die Ausgabe mit -Wrap und -Autosize

Get-Service | Format-Table -Wrap -AutoSize


# Listen Sie die Dienste in einer Liste auf

Get-Service | Format-List

### Expressions

# Ermitteln Sie die neuesten 5 Einträge aus dem System Logfile und geben Sie die 
# Daten EventID,EntryType und Message in einer Tabelle 
# so aus, dass die Spalten der Werte 
# EventID als Ereigniskennung, der EntryType als Eintragstyp und die Message als Ereignistext beschriftet sind

Get-EventLog -LogName System -Newest 5 | Format-Table @{n="Ereigniskennung";e={$_.EventId}}, @{n="Eintragstyp";e={$_.EntryType}}, @{n="Ereignistext";e={$_.Message}}
  
# Mit align="left" kann die Ereigniskennung linksbündig angezeigt werden. Ändern Sie die Lösung dahingehend

Get-EventLog -LogName System -Newest 5 | Format-Table @{n="Ereigniskennung";e={$_.EventId};align="left"}, @{n="Eintragstyp";e={$_.EntryType}}, @{n="Ereignistext";e={$_.Message}}
 
# Optionale Übung:
# Ermitteln Sie mit dem Befehl Get-Volume für das Laufwerk C Speicherinformationen.
# Listen Sie in einer Tabelle den Laufwerksbuchstaben als "LW" die Gesamtspeichergrösse als "Platz (GB)" ohne Nachkommastellen 
# und den belegten Speicher in Prozent als "Belegt (%)" mit 2 Nachkommastellen auf. 
# Sie müssen dazu Expressions einsetzen.

Get-Volume -DriveLetter C | Format-Table @{n="LW";e={$_.DriveLetter}}, @{n="Platz (GB)";e={"{0:N0}" -f ($_.Size / 1GB)}}, @{n="Belegt (%)";e={"{0:N2}" -f (($_.sizeremaining / $_.size) *100)}}
