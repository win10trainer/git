﻿# Die ISE ist zum Entwickeln von Scripten. Alternativ gibt es diverse Editoren, z.B. VS Code (gratis)
# Die Konsole ist bevorzugt für einzelne Kommandos oder für das Ausführen fertiger Skripte

# Mit welcher Powershell Version arbeiten Sie?

$PSVersionTable

# Welche Programme kann ich nicht in der Konsole starten (weil sie eine eigene Shell haben)

$psUnsupportedConsoleApplications

# Können Sie Scripte ausführen? Wie sind die Einstellungen der verschieden Bereiche?

Get-ExecutionPolicy -List


<#  MachinePolicy      wird per GPO (oder mit -scope) erteilt, höchste Priorität  
    UserPolicy         wird per GPO (oder mit -scope) erteilt
    Process            beim Start festgelegt (powershellexe -excutionpolicy allsigned)
    CurrentUser        set-executionpolicy  unrestricted -scope:currentuser
    LocalMachine       set-executionpolicy bypass -scope localmachine
 #>

#Stellen Sie die Richtlinie so ein, dass Remotescripte für LocalMachine signiert sein müssen.

Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope LocalMachine -force
# oder auch: Set-ExecutionPolicy Remote-Signed

# Einstellungen der ISE z.B. unter Tools/Optionen:
# --> Schauen Sie in der ISE unter Tools/Optionen die Einstellungen an. Passen Sie die Farbe
# an, die bei der Fehleranzeige standarmässig Rot ist, so dass Sie die Fehler besser lesen können, z.B. auf Grau
#
# Stellen Sie in der Konsole die Fehlerfarbe auf "Gray"

$Host.PrivateData.ErrorForegroundColor = "Gray"
