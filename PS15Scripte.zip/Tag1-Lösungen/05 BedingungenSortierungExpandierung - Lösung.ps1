﻿# Man kann oft bereits am Anfang filtern. Weitere Filteroptionen bietet das Where-Object
# Mit dem Select-Object können einzelne Eigenschaften ausgewählt werden, während die anderen
# nicht mehr weitergeleitet werden. Zum Sortieren wird das Sort-Object verwendet.


#Filtern: Zeigen Sie in einem Befehl alle Dienste an, deren Displayname mit S beginnt an.

Get-Service S*

#zeigen Sie von allen Diensten, deren Displayname mit S beginnt, den Displayname und Status in einer Tabelle an.

Get-Service S* | Format-Table DisplayName,Status

# Ermittel Sie alle Dienste, die mit s beginnen und geben Sie von diesen den Displayname und Status in eine Datei C:\sdienste.txt aus.
# Diese Datei soll nach dem Status sortiert sein

Get-Service | Sort-Object Status | Select-Object DisplayName,Status | Out-File C:\sdienste.txt
 

# Filtern Sie die Dienste, deren Anzeigenamen mit S oder B beginnen und sortieren Sie sie nach dem Anzeigenamen

Get-Service "s*","b*" | sort DisplayName
 

# Filtern Sie die Dienste, deren Anzeigenamen mit S oder B beginnen und sortieren Sie sie nach dem Anzeigenamen, 
# wobei laufende Dienste in grüner Schrift angezeigt werden sollen und nicht laufende in Weiss. Verwenden Sie
# zur Ausgabe write-host mit dem Parameter -ForeGroundColor. Nutzen Sie das Foreach-Object.
    
Get-Service "s*","b*" | Sort-Object DisplayName | ForEach-Object { if ($_.status -eq "running") { Write-Host $_.DisplayName -ForegroundColor Green} else { write-host $_.DisplayName -ForegroundColor White }}


#Finden Sie alle Ereignisse vom Eintagstyp Fehler (error) in der Ereignisanzeige für das Logfile System
Get-EventLog System -EntryType Error

# Finden Sie in der Ereignisanzeige für das Logfile System in den neuesten 100 Ereignissen alle Ereignisse
# die nicht die Ereignis-ID 7036 besitzen. Geben Sie die Werte EventID,Source,Message in einer Liste aus.

Get-EventLog System -Newest 100 | Where-Object eventid -ne 7036 | Format-Table eventid,source,message



 
# Finden Sie in der Ereignisanzeige für das Logfile System in den neuesten 300 Ereignissen alle Ereignisse die
# entweder ein Fehler oder eine Information darstellen. Geben Sie die EntryType,EventID,Source in einer Liste aus

Get-EventLog System -Newest 300 -EntryType Error,Information | Format-Table eventid,source,message

 
#Führen Sie die gleiche Abfrage durch, aber geben Sie das Ergebnis so aus, daß nach Entrytype gruppiert wird

Get-EventLog System -newest 300 -EntryType Error,Information | Sort-Object EntryType,Source | Format-Table entrytype,source,message -wrap -AutoSize -GroupBy entrytype

#alternativ
Get-EventLog System -newest 300 | Where-Object {$_.EntryType -eq "information" -or $_.EntryType -eq "error"}    | sort EntryType,Source | ft entrytype,source,message -wrap -AutoSize -GroupBy entrytype

# wenn nur ein Ereignistyp auftaucht, dann einfach das ganze logfile durchsuchen
Get-EventLog System | Where-Object {$_.EntryType -eq "information" -or $_.EntryType -eq "error"}    | Sort-Object EntryType,Source | Format-Table entrytype,source,message -Wrap -AutoSize -GroupBy entrytype

# expandproperty:
# Wie viele Prozesse sind gerade bekannt? Zählen Sie die Eigenschaft ID mit dem Measure-Object. Geben Sie nur den IntegerWert aus.
# Prüfen Sie dazu mit dem Get-Member CmdLet was für ein Object vom Measure-Object ausgeben wird und finden Sie einen Weg nur einen
# Integerwert zu erhalten.

Get-Process | Measure-Object Id | Select-Object -ExpandProperty count


#Weiteres Beispiel für den Einsatz
Get-Service | Where-Object DependentServices -ne $null | foreach { $1 = $_.name ; $2 = ($_ | select -expandproperty DependentServices | select -ExpandProperty displayname) ; write-Host $1 "hat folgende DependentServices:" $2}
