﻿# Aktualisieren Sie die Hilfedateien

Update-Help


# Übung zur Verwendung von Get-command zum Suchen von Befehlen:
# Wie können Sie Befehle, die Prozesse (engl. Process) betreffen, finden?

Get-Command -Name *process*

# Finden Sie heraus, wie man get-command verwendet und zeigen Sie die Hilfe in einem gesonderten Fenster an:

Get-Help Get-Command -ShowWindow
 

# Powershell stellt die Kommandos in Modulen bereit. Aus welchem Modul (Source) stammt Get-NetIpaddress

Get-command Get-NetIPAddress


# Welche Befehle gibt es in dem Modul?


Get-Command -Module NetTCPIP 

# Finden Sie Befehle, mit denen man Powershell-Module verwalten kann.

Get-Command *module*

# Finden Sie heraus, was der Befehl get-modul bewirkt:

Get-Help Get-Module 

# Wie lautet der Befehl, der alle Module auflistet, auch nicht geladene?

Get-Module -ListAvailable


# Kann man Ereignisanzeige das Logfile System anzeigen? Suchen Sie nach *event* Kommandos.

Get-Command *event*

# Das ergibt viele Ergebnisse.. 
# Für Befehle die etwas anzeigen sollen, wird das Verb Get benutzt: Get-*event*. Suchen Sie damit.


Get-Command get-*event*


# Es passt Get-Eventlog. Welche Parameter hat der Befehl? Zeigen Sie die Hilfe in einem gesonderten Fenster an:

Get-Help Get-EventLog -ShowWindow

# Die Hilfe gibt an, daß ein Logfilename verwendet werden muss und z.B. auch, daß 
# man die ausgegebene Anzahl der Ereignisse auf die neuesten 10 beschränken kann.
# Mit welchen Befehl können Sie die neuesten 10 Ereignisse des Systemlogfile (System) anzeigen?

Get-EventLog System -Newest 10


# Die Hilfe umfasst auch die "about_" Dateien. Mit welchem Befehl können Sie sie auflisten?

Get-Help about_*

# Wie erstellt man Aliase? Zeigen Sie die "about_" Hilfe zum Thema Alias in einem eigenen Fenster an.

Get-Help about_aliases -ShowWindow

# Erstellen Sie den Alias spro um einen Prozess zu stoppen.

New-Alias -Name spro -Value Stop-Process

#Für welche CmdLet steht der alias GCM?

Get-Alias GCM # Für Get-Command

