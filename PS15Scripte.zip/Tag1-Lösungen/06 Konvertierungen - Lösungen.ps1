﻿# Welche Befehle konvertieren von oder zu speziellen Datenformaten (Verben: ConvertFRom- ConvertTo-) ? 
# Nicht alle Ergebnisse bei einer einfachen Suche passen. 
# Relevante Ergebnisse stammen aus dem Module Microsoft.Powershell.Utility


Get-Command convert* -Module Microsoft.Powershell.Utility


# Welche Befehle exportieren oder importieren Daten in spezielle Formate?
# Nicht alle Ergebnisse bei einer einfachen Suche passen. 
# Relevante Ergebnisse stammen aus dem Module Microsoft.Powershell.Utility

Get-Command export*,import* -Module Microsoft.Powershell.Utility


# Exportieren Sie die Prozessinformationen in eine CSV Datei C:\test\ExportCsv.csv (verwenden Sie -force um den Ordner zu erstellen)

Get-Process | Export-Csv -Path C:\test\exportcsv.csv -Force


# Konvertieren Sie die Prozessinformationen in CSV und geben Sie das Ergebnis mit out-file in C:\test\convertcsv.txt aus

Get-Process | ConvertTo-Csv | Out-File C:\test\convertcsv.txt

# Wo ist der Unterschied in der Funktion beider Befehle?
# Antwort: convertto-csv konvertiert im Speicher, Export-csv schreibt in eine Datei. Es werden auch unterschiedliche Standars bei der Codierung verwendet

<# Erfassen Sie alle Dienste mit Name, Anzeigenamen und Status und geben Sie sie in einer HTLM Datei aus
 
 Verwenden Sie folgende zusätzlichen Eigenschaften:
 Body: "<H1> Alle Dienste </H1><br>"
 Title: "Anzeige der Dienste"
 Postcontent: "<br><H1>Copyright Administrator</H1>"
 Precontent: "Hier werden die Dienste aufgelistet <br><br>"

#>

Get-Service | ConvertTo-Html -Property Name,DisplayName,Status -Body "<H1> Alle Dienste </H1><br>" -Title "Anzeige der Dienste" -PostContent "<br><h1>Copyright Administrator</H1>" -PreContent "Hier werden die Dienste aufgelistet <br><br>" | Out-File -FilePath C:\test\services.htmlInvoke-Item C:\test\services.html# Mit Datum und Uhrzeit aufgehübscht:$d = (Get-Date).ToShortDateString() + " " + (get-date).ToShortTimeString() + " Uhr"$Precontent = "hier werden die Dienste aufgelistet: " + $dGet-Service | ConvertTo-Html -Property Name,DisplayName,Status -Body "<H1> Alle Dienste </H1><br>" -Title "Anzeige der Dienste" -PostContent "<br><h1>Copyright Administrator</H1>" -PreContent $Precontent | Out-File -FilePath C:\test\services.html